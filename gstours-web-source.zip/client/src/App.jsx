import React, { useState, useEffect } from "react";
import { api } from "./api.js";
import Login from "./Login.jsx";
import CRM from "./CRM.jsx";

export default function App() {
  const [status, setStatus] = useState("checking"); // checking | needsSetup | needsLogin | signedIn
  const [user, setUser] = useState(null);

  useEffect(() => {
    (async () => {
      try {
        const me = await api.me();
        if (me) { setUser(me); setStatus("signedIn"); return; }
      } catch (e) { /* not signed in, fall through */ }
      try {
        const { hasUsers } = await api.authStatus();
        setStatus(hasUsers ? "needsLogin" : "needsSetup");
      } catch (e) {
        setStatus("needsLogin"); // safest default if the status check itself fails
      }
    })();
  }, []);

  const handleSignedIn = (u) => { setUser(u); setStatus("signedIn"); };

  if (status === "checking") {
    return <div style={{ padding: 40, fontFamily: "system-ui", color: "#67788C" }}>Loading…</div>;
  }
  if (status === "signedIn") {
    return <CRM currentUser={user} onSignOut={async () => { await api.logout(); setUser(null); setStatus("needsLogin"); }} />;
  }
  return <Login needsSetup={status === "needsSetup"} onSignedIn={handleSignedIn} />;
}
