import React, { useState } from "react";
import { api } from "./api.js";

export default function Login({ onSignedIn, needsSetup }) {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState("");
  const [busy, setBusy] = useState(false);

  const submit = async (e) => {
    e.preventDefault();
    setError("");
    setBusy(true);
    try {
      const user = needsSetup
        ? await api.setup(email, password, name)
        : await api.login(email, password);
      onSignedIn(user);
    } catch (err) {
      setError(err.message || "Something went wrong");
    } finally {
      setBusy(false);
    }
  };

  return (
    <div style={{
      minHeight: "100vh", display: "flex", alignItems: "center", justifyContent: "center",
      background: "#F4F6F8", fontFamily: "Inter, system-ui, sans-serif"
    }}>
      <form onSubmit={submit} style={{
        background: "#fff", padding: "40px 36px", borderRadius: 14, width: 360,
        boxShadow: "0 4px 24px rgba(16,62,98,.08)", border: "1px solid #DFE6EE"
      }}>
        <div style={{ fontFamily: "'Barlow Condensed', sans-serif", fontWeight: 700, fontSize: 28, color: "#103E62", letterSpacing: 0.3 }}>
          GS Tours
        </div>
        <div style={{ color: "#67788C", fontSize: 13.5, marginBottom: 24 }}>
          {needsSetup ? "Set up the first account for this CRM" : "Sign in to your CRM"}
        </div>

        {needsSetup && (
          <div style={{ marginBottom: 14 }}>
            <label style={{ fontSize: 12, fontWeight: 600, color: "#33465C" }}>Your name</label>
            <input value={name} onChange={e => setName(e.target.value)}
              style={inputStyle} placeholder="Parminder Singh Gill" />
          </div>
        )}

        <div style={{ marginBottom: 14 }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#33465C" }}>Email</label>
          <input type="email" required value={email} onChange={e => setEmail(e.target.value)}
            style={inputStyle} placeholder="you@gstours.nl" />
        </div>

        <div style={{ marginBottom: 8 }}>
          <label style={{ fontSize: 12, fontWeight: 600, color: "#33465C" }}>Password</label>
          <input type="password" required minLength={needsSetup ? 8 : undefined}
            value={password} onChange={e => setPassword(e.target.value)}
            style={inputStyle} placeholder={needsSetup ? "At least 8 characters" : ""} />
        </div>

        {error && (
          <div style={{ background: "#FBE7E7", color: "#8A2222", fontSize: 12.5, padding: "8px 10px", borderRadius: 8, marginTop: 10 }}>
            {error}
          </div>
        )}

        <button type="submit" disabled={busy} style={{
          width: "100%", marginTop: 18, padding: "11px 0", borderRadius: 9, border: 0,
          background: "#103E62", color: "#fff", fontWeight: 700, fontSize: 14.5,
          cursor: busy ? "default" : "pointer", opacity: busy ? 0.7 : 1
        }}>
          {busy ? "Please wait\u2026" : needsSetup ? "Create account" : "Sign in"}
        </button>
      </form>
    </div>
  );
}

const inputStyle = {
  width: "100%", padding: "9px 11px", marginTop: 4, borderRadius: 8,
  border: "1px solid #DFE6EE", fontSize: 14, fontFamily: "inherit", boxSizing: "border-box"
};
